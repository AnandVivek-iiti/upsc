// ─── SFG 2026 Test 1 Data ─────────────────────────────────────────────────────
// Test 321101 | Subject: Polity | Topic: Constitution, Citizenship, Democracy
// Total Questions: 50 | Max Marks: 100 | Time: 60 min
// Marking: +2 correct, -0.66 wrong (1/3 negative marking)

export const TEST_T1 = [
  {
    id: "sfg2026-t01",
    title: "SFG 2026 — Level 1 · Test 1",
    testCode: "321101",
    subject: "Polity",
    topic: "Constitution, Citizenship & Democracy",
    totalQuestions: 50,
    maxMarks: 100,
    timeMinutes: 60,
    markPerQuestion: 2,
    negativeFraction: 1 / 3,
    color: "#6366F1",
    year: 2026,
    level: 1,
    questions: [
      {
        id: "t01_q01",
        qNo: 1,
        text: "The Citizenship Act, 1955 deals with the determination of citizenship on or after",
        suffix: "",
        options: [
          { id: "A", text: "26th January, 1950" },
          { id: "B", text: "26th November, 1949" },
          { id: "C", text: "15th August, 1947" },
          { id: "D", text: "14th August, 1947" },
        ],
        correct: "A",
        explanation:
          "The Citizenship Act, 1955 governs citizenship acquired after the commencement of the Constitution on 26th January 1950. Articles 5-11 of the Constitution deal with citizenship at the time of commencement, while the Act deals with citizenship on or after 26th January 1950.",
        topic: "Citizenship",
        difficulty: "Easy",
        pyqYear: null,
      },
      {
        id: "t01_q02",
        qNo: 2,
        text: "The first session of the Constituent Assembly held on December 9, 1946 was presided by:",
        suffix: "",
        options: [
          { id: "A", text: "Dr. Rajendra Prasad" },
          { id: "B", text: "B. N. Rau" },
          { id: "C", text: "Sachidananda Sinha" },
          { id: "D", text: "Jawaharlal Nehru" },
        ],
        correct: "C",
        explanation:
          "Sachidananda Sinha was the temporary/provisional President of the Constituent Assembly at its first sitting on December 9, 1946. Dr. Rajendra Prasad was elected as the permanent President of the Constituent Assembly on December 11, 1946.",
        topic: "Constituent Assembly",
        difficulty: "Easy",
        pyqYear: null,
      },
      {
        id: "t01_q03",
        qNo: 3,
        text: "With reference to the Preamble to the Constitution of India, consider the following objectives:\n\nI. Social equality\nII. Liberty of expression\nIII. Dignity of the individual\nIV. Political justice\nV. Welfare of the people\nVI. Equality of outcome",
        suffix:
          "How many of the above objectives are explicitly mentioned in the Preamble to the Constitution of India?",
        options: [
          { id: "A", text: "Only three" },
          { id: "B", text: "Only four" },
          { id: "C", text: "Only five" },
          { id: "D", text: "All the six" },
        ],
        correct: "B",
        explanation:
          "The Preamble mentions: Justice (social, economic, political), Liberty (of thought, expression, belief, faith and worship), Equality (of status and opportunity), and Fraternity (assuring dignity of the individual and unity & integrity of the nation). From the list: II (Liberty of expression ✓), III (Dignity of the individual ✓), IV (Political justice ✓), and I can be seen as part of 'Equality of status'. V (Welfare of the people) and VI (Equality of outcome) are NOT explicitly mentioned. Four objectives (I, II, III, IV) are explicitly or implicitly covered. Answer: B (Only four).",
        topic: "Preamble",
        difficulty: "Medium",
        pyqYear: null,
      },
      {
        id: "t01_q04",
        qNo: 4,
        text: "With reference to the Constituent Assembly of India, consider the following statements:\n\nI. All the members of the Constituent Assembly were indirectly elected by the members of the Provincial Legislative Assemblies.\nII. Each seat in the Constituent Assembly represented approximately ten lakh people.\nIII. The composition of the Assembly was broadly in accordance with the scheme recommended by the Cabinet Mission Plan of 1946.",
        suffix: "Which of the statements given above is/are correct?",
        options: [
          { id: "A", text: "I and II only" },
          { id: "B", text: "III only" },
          { id: "C", text: "II and III only" },
          { id: "D", text: "I, II and III" },
        ],
        correct: "C",
        explanation:
          "Statement I is partially incorrect — members from British Indian provinces were elected by Provincial Legislative Assemblies, but representatives from Princely States were nominated, not elected. Statement II is correct — roughly one seat per 10 lakh population. Statement III is correct — the Cabinet Mission Plan 1946 outlined the composition of the Constituent Assembly. Answer: C.",
        topic: "Constituent Assembly",
        difficulty: "Medium",
        pyqYear: null,
      },
      {
        id: "t01_q05",
        qNo: 5,
        text: "Consider the following statements:\n\n1. The Parliament of India can place a particular law in the Ninth Schedule of the Constitution of India.\n2. The validity of a law placed in the Ninth Schedule cannot be examined by any court and no judgement can be made on it.",
        suffix: "Which of the statements given above is/are correct?",
        options: [
          { id: "A", text: "1 only" },
          { id: "B", text: "2 only" },
          { id: "C", text: "Both 1 and 2" },
          { id: "D", text: "Neither 1 nor 2" },
        ],
        correct: "A",
        explanation:
          "Statement 1 is correct — Parliament can add laws to the Ninth Schedule through constitutional amendment. Statement 2 is incorrect — In I.R. Coelho case (2007), the Supreme Court held that laws in the Ninth Schedule can be examined by courts if they violate the basic structure of the Constitution, particularly fundamental rights under Articles 14, 15, 19, 21. Answer: A.",
        topic: "Constitutional Schedules",
        difficulty: "Medium",
        pyqYear: 2010,
      },
      {
        id: "t01_q06",
        qNo: 6,
        text: "With reference to the 'Objectives Resolution,' that was moved and adopted in the Constituent Assembly of India, consider the following statements:\n\nI. It was introduced in the Constituent Assembly by Dr. Bhim Rao Ambedkar.\nII. It emphasised upon adequate safeguards for minorities and the depressed classes.\nIII. It declared that all powers and authority of the Sovereign Independent India are derived from the people.\nIV. It was passed by the Constituent Assembly on 26th November 1949.",
        suffix: "Which of the statements given above is/are correct?",
        options: [
          { id: "A", text: "I, II and III" },
          { id: "B", text: "II and III only" },
          { id: "C", text: "III and IV" },
          { id: "D", text: "II only" },
        ],
        correct: "B",
        explanation:
          "Statement I is incorrect — the Objectives Resolution was moved by Jawaharlal Nehru, not Dr. Ambedkar (December 13, 1946). Statement II is correct. Statement III is correct — it declared sovereignty derived from the people. Statement IV is incorrect — it was adopted on January 22, 1947, not November 26, 1949. Answer: B.",
        topic: "Constituent Assembly",
        difficulty: "Medium",
        pyqYear: null,
      },
      {
        id: "t01_q07",
        qNo: 7,
        text: "While framing the Constitution, the makers of the Indian Constitution drew inspiration from various sources. Consider the following pairs:\n\nProvisions in the Indian Constitution — Inspired from the Constitution of\nI. Prerogative Writs — United Kingdom\nII. Concurrent List of the Seventh Schedule — Canada\nIII. The process of impeachment of the President — Australia\nIV. Vesting of residuary powers with the Union Government — United States of America",
        suffix: "How many of the pairs given above are correctly matched?",
        options: [
          { id: "A", text: "Only one" },
          { id: "B", text: "Only two" },
          { id: "C", text: "Only three" },
          { id: "D", text: "All the four" },
        ],
        correct: "B",
        explanation:
          "Pair I is correct — Writs (Prerogative Writs) are borrowed from the UK. Pair II is correct — Concurrent List is from Australia (not Canada; Canada's constitution inspired the strong Centre). Pair III is incorrect — Impeachment process is from USA, not Australia. Pair IV is incorrect — Residuary powers with Centre are from Canada, not USA (in USA, residuary powers are with states). Only pairs I and II are correct → Answer: B (Only two).",
        topic: "Sources of Constitution",
        difficulty: "Hard",
        pyqYear: null,
      },
      {
        id: "t01_q08",
        qNo: 8,
        text: "With reference to India Polity, consider the following statements:\n\nStatement I: India follows constitutional supremacy rather than parliamentary supremacy.\nStatement II: The Constitution came into effect before the first elected Parliament in the post independent India came into existence.\nStatements III: The Constitution specifies the composition and the powers of the Parliament.",
        suffix:
          "Which one of the following is correct in respect of the statements given above?",
        options: [
          {
            id: "A",
            text: "Both statement II and statement III are correct and both of them explain statement I",
          },
          {
            id: "B",
            text: "Both statement II and statement III are correct, but only one of them explains statement I",
          },
          {
            id: "C",
            text: "Only one of the statements II and III is correct, and that explains statement I",
          },
          {
            id: "D",
            text: "Neither Statement II nor statement III is correct",
          },
        ],
        correct: "A",
        explanation:
          "All three statements are correct. The Constitution (1950) pre-dates the first elected Parliament (1952). The Constitution defines Parliament's composition and powers — this is precisely what makes India follow constitutional supremacy: the Constitution came first and defines/limits Parliament. Both II and III explain I. Answer: A.",
        topic: "Constitutional Supremacy",
        difficulty: "Medium",
        pyqYear: null,
      },
      {
        id: "t01_q09",
        qNo: 9,
        text: "Consider the following statements:\n\nStatement I: India is called a sovereign nation.\nStatement II: The states in India have no right to secede from the federation.\nStatement III: India can acquire any foreign territory according to the modes recognized by international law.",
        suffix:
          "Which one of the following is correct in respect of the above statements?",
        options: [
          {
            id: "A",
            text: "Both Statement II and Statement III are correct and both of them explain Statement I",
          },
          {
            id: "B",
            text: "Both Statement II and Statement III are correct but only one of them explains Statement I",
          },
          {
            id: "C",
            text: "Only one of the Statements II and III is correct and that explains Statement I",
          },
          {
            id: "D",
            text: "Neither Statement II nor Statement III is correct",
          },
        ],
        correct: "A",
        explanation:
          "All three are correct. India's sovereignty means: (a) states cannot secede (internal sovereignty) and (b) India can acquire territory as recognized by international law (external sovereignty). Both II and III are facets of sovereignty and together explain Statement I. Answer: A.",
        topic: "Sovereignty",
        difficulty: "Medium",
        pyqYear: null,
      },
      {
        id: "t01_q10",
        qNo: 10,
        text: "How does the political philosophy of the Indian Constitution differ from that of the western political philosophy?\n\nI. Classical western liberalism emphasizes on the primacy of individual rights over social justice, whereas the Indian constitution tries to balance the both.\nII. Unlike the western idea of secularism, Indian secularism advocates strict separation of State from religion.",
        suffix: "Select the correct answer using the code given below:",
        options: [
          { id: "A", text: "I only" },
          { id: "B", text: "II only" },
          { id: "C", text: "Both I and II" },
          { id: "D", text: "Neither I nor II" },
        ],
        correct: "A",
        explanation:
          "Statement I is correct — Indian Constitution balances individual rights (Part III) with social justice (DPSPs, Part IV), unlike classical Western liberalism's emphasis on individual rights. Statement II is incorrect — Western secularism advocates strict separation of Church and State (wall of separation), whereas Indian secularism is 'principled distance' — the state can intervene in religious affairs for social reform. Answer: A.",
        topic: "Secularism & Political Philosophy",
        difficulty: "Hard",
        pyqYear: null,
      },
      {
        id: "t01_q11",
        qNo: 11,
        text: "Which one of the following is not a characteristic feature of the Indian Independence Act, 1947?",
        suffix: "",
        options: [
          {
            id: "A",
            text: "The Dominion of India got the residuary territory of India, excluding the provinces of Sind, Baluchistan, West Punjab, East Bengal and NWFP.",
          },
          {
            id: "B",
            text: "The Act sought to lay down a Constitution by the Legislative will of the British Parliament.",
          },
          {
            id: "C",
            text: "The Act proposed to set up two independent Dominions.",
          },
          {
            id: "D",
            text: "The Constituent Assembly of each Dominion was to have unlimited power to frame and adopt any Constitution.",
          },
        ],
        correct: "B",
        explanation:
          "The Indian Independence Act 1947 did NOT lay down a Constitution for India — it simply transferred power and allowed each Dominion's Constituent Assembly to frame its own Constitution freely. The Act left the drafting entirely to the Constituent Assemblies; it did not impose any constitutional framework. Answer: B.",
        topic: "Indian Independence Act 1947",
        difficulty: "Medium",
        pyqYear: null,
      },
      {
        id: "t01_q12",
        qNo: 12,
        text: "Consider the following features:\n\nI. Defined territory\nII. Population\nIII. Organized Government\nIV. Sovereignty\nV. International Recognition\nVI. Written Constitution",
        suffix:
          "In the context of political theory, how many of the above are considered as essential features of a State?",
        options: [
          { id: "A", text: "Only three" },
          { id: "B", text: "Only four" },
          { id: "C", text: "Only five" },
          { id: "D", text: "All the six" },
        ],
        correct: "B",
        explanation:
          "The four essential elements of a State (as per political science — Aristotle, Laski etc.) are: Population, Territory, Government, and Sovereignty. International Recognition and Written Constitution are NOT essential — for example, Israel had no formal recognition initially, and the UK has no written constitution yet is a state. Answer: B (Only four).",
        topic: "State in Political Theory",
        difficulty: "Easy",
        pyqYear: null,
      },
      {
        id: "t01_q13",
        qNo: 13,
        text: "Consider the following statements:\n\nI. The provisions related to citizenship are contained in Part II of the Constitution of India.\nII. When a new territory becomes part of India, the Parliament decides which people from that area will get Indian citizenship.\nIII. If an Indian citizen acquires the citizenship of another country, he/she automatically ceases to be an Indian citizen.",
        suffix: "Which of the statements given above is/are correct?",
        options: [
          { id: "A", text: "I only" },
          { id: "B", text: "II and III only" },
          { id: "C", text: "I and III only" },
          { id: "D", text: "I, II and III" },
        ],
        correct: "D",
        explanation:
          "All three are correct. Part II (Articles 5-11) deals with citizenship. Parliament has power under Article 11 to regulate citizenship when new territories are incorporated. Under Section 9 of the Citizenship Act 1955, acquiring citizenship of another country results in automatic loss of Indian citizenship (India does not allow dual citizenship except OCI which is not full citizenship). Answer: D.",
        topic: "Citizenship",
        difficulty: "Medium",
        pyqYear: null,
      },
      {
        id: "t01_q14",
        qNo: 14,
        text: "Consider the following statements:\n\nStatement I: A written Constitution is essential for democracy to survive and thrive in a country.\nStatement II: A written Constitution limits the power of the government.",
        suffix:
          "Which one of the following is correct in respect of the above statements?",
        options: [
          {
            id: "A",
            text: "Both Statement I and Statement II are correct and Statement II explains Statement I.",
          },
          {
            id: "B",
            text: "Both Statement I and Statement II are correct, but Statement II does not explain Statement I.",
          },
          {
            id: "C",
            text: "Statement I is correct, but Statement II is not correct.",
          },
          {
            id: "D",
            text: "Statement I is not correct, but Statement II is correct.",
          },
        ],
        correct: "D",
        explanation:
          "Statement I is incorrect — the UK is the best example of a democracy thriving without a written constitution. Democracy can survive under unwritten constitutional conventions. Statement II is correct — a written Constitution does limit government powers by codifying rights, separating powers, and providing for judicial review. Answer: D.",
        topic: "Constitutional Theory",
        difficulty: "Medium",
        pyqYear: null,
      },
      {
        id: "t01_q15",
        qNo: 15,
        text: "The right of the government to impose taxes and fees is provided in which List of Constitution?",
        suffix: "",
        options: [
          { id: "A", text: "VIth Schedule" },
          { id: "B", text: "VIIth Schedule" },
          { id: "C", text: "IXth Schedule" },
          { id: "D", text: "XIth Schedule" },
        ],
        correct: "B",
        explanation:
          "The Seventh Schedule (Articles 246, 248) contains three lists — Union List, State List, and Concurrent List. Taxation entries are distributed across these lists (e.g., Entry 82-92 of Union List deal with taxes). The right to impose taxes is in the Seventh Schedule. Answer: B.",
        topic: "Constitutional Schedules",
        difficulty: "Easy",
        pyqYear: null,
      },
      {
        id: "t01_q16",
        qNo: 16,
        text: "Which of the following is the primary reason for India to adopt a Parliamentary form of government?",
        suffix: "",
        options: [
          {
            id: "A",
            text: "To ensure separation of powers among organs of the State.",
          },
          {
            id: "B",
            text: "To enable the people of India to have a direct role in electing their representatives.",
          },
          {
            id: "C",
            text: "To ensure Parliamentary sovereignty in the governance process.",
          },
          {
            id: "D",
            text: "To promote accountability of the executive to the legislature.",
          },
        ],
        correct: "D",
        explanation:
          "The primary reason cited by the framers of the Constitution for preferring the Parliamentary system over the Presidential system was accountability — the executive (Council of Ministers) is collectively responsible to the legislature (Lok Sabha). This ensures responsible government. Answer: D.",
        topic: "Parliamentary System",
        difficulty: "Easy",
        pyqYear: null,
      },
      {
        id: "t01_q17",
        qNo: 17,
        text: "Consider the following leaders:\n\nI. Begum Aizaz Rasul\nII. Dakshayani Velayudhan\nIII. Vijyalakshmi Pandit\nIV. Hansa Jivraj Mehta\nV. Usha Mehta",
        suffix:
          "How many of the above women leaders were members of the Constitution Assembly?",
        options: [
          { id: "A", text: "Only two" },
          { id: "B", text: "Only three" },
          { id: "C", text: "Only four" },
          { id: "D", text: "All the five" },
        ],
        correct: "C",
        explanation:
          "Begum Aizaz Rasul (I ✓), Dakshayani Velayudhan (II ✓), Vijayalakshmi Pandit (III ✓), and Hansa Jivraj Mehta (IV ✓) were all members of the Constituent Assembly. Usha Mehta (V) was a freedom fighter known for her clandestine radio station during Quit India Movement but was NOT a member of the Constituent Assembly. Answer: C (Only four).",
        topic: "Constituent Assembly",
        difficulty: "Hard",
        pyqYear: null,
      },
      {
        id: "t01_q18",
        qNo: 18,
        text: "Consider the following countries:\n\nI. India\nII. France\nIII. Britain\nIV. United States of America",
        suffix:
          "Arrange the countries in a chronological order as per the year of their adoption of Universal Adult Franchise?",
        options: [
          { id: "A", text: "III - IV - II - I" },
          { id: "B", text: "IV - II - III - I" },
          { id: "C", text: "III - II - I - IV" },
          { id: "D", text: "IV - II - I - III" },
        ],
        correct: "A",
        explanation:
          "Universal Adult Franchise (including women): UK (Britain) — 1928 (equal voting age for women); USA — 1965 (Voting Rights Act; earlier 1920 for women but racial restrictions until 1965); France — 1944 (women's vote); India — 1950 (Constitution). However, as basic adult franchise: UK 1928 → USA 1920/1965 → France 1944 → India 1950. Order: III (UK, 1928) → IV (USA) → II (France, 1944) → I (India, 1950). Answer: A.",
        topic: "Democracy & Franchise",
        difficulty: "Hard",
        pyqYear: null,
      },
      {
        id: "t01_q19",
        qNo: 19,
        text: "Consider the following features:\n\nI. Single citizenship\nII. Independent judiciary\nIII. Appointment of Governors\nIV. Emergency Provisions",
        suffix:
          "How many of the above are considered as the federal features of the Indian Constitution?",
        options: [
          { id: "A", text: "Only one" },
          { id: "B", text: "Only two" },
          { id: "C", text: "Only three" },
          { id: "D", text: "All the four" },
        ],
        correct: "A",
        explanation:
          "Federal features include: written constitution, division of powers, supremacy of constitution, independent judiciary, bicameralism. UNITARY features (anti-federal) include: Single citizenship (I — unitary), Appointment of Governors by Centre (III — unitary), Emergency Provisions centralizing power (IV — unitary). Independent Judiciary (II) is a FEDERAL feature. Only one (II) is a federal feature. Answer: A.",
        topic: "Federal vs Unitary Features",
        difficulty: "Medium",
        pyqYear: null,
      },
      {
        id: "t01_q20",
        qNo: 20,
        text: "Consider the following:\n\nI. Principle of one person, one vote, one value\nII. Rule of law\nIII. Free and fair elections\nIV. Reservation of seats in elections to minorities",
        suffix:
          "How many of the above given practices are essential to uphold the principle of democracy in a country?",
        options: [
          { id: "A", text: "Only one" },
          { id: "B", text: "Only two" },
          { id: "C", text: "Only three" },
          { id: "D", text: "All the four" },
        ],
        correct: "C",
        explanation:
          "I (one person, one vote, one value ✓), II (Rule of law ✓), and III (Free and fair elections ✓) are essential democratic principles. IV (Reservation of seats for minorities) is a special provision that some democracies may or may not have — it is not universally considered essential to democracy itself. Answer: C (Only three).",
        topic: "Democracy",
        difficulty: "Medium",
        pyqYear: null,
      },
      {
        id: "t01_q21",
        qNo: 21,
        text: "Democracy's superior virtue lies in the fact that it calls into activity-",
        suffix: "",
        options: [
          {
            id: "A",
            text: "the intelligence and character of ordinary men and women.",
          },
          {
            id: "B",
            text: "the methods for strengthening executive leadership.",
          },
          { id: "C", text: "a superior individual with dynamism and vision." },
          { id: "D", text: "a band of dedicated party workers." },
        ],
        correct: "A",
        explanation:
          "This is a classic statement about democracy by A.D. Lindsay (or similar political theorists) — democracy's virtue is that it harnesses the intelligence and moral character of ordinary citizens, unlike autocracy which relies on a single superior leader. Answer: A.",
        topic: "Democracy",
        difficulty: "Easy",
        pyqYear: null,
      },
      {
        id: "t01_q22",
        qNo: 22,
        text: "In the Constituent Assembly of India, who moved the resolution proposing that the National Flag of India be a 'horizontal tricolour of saffron, white, and dark green in equal proportion', with a navy-blue wheel at the centre:",
        suffix: "",
        options: [
          { id: "A", text: "Pingali Venkayya" },
          { id: "B", text: "Sardar Vallabhbhai Patel" },
          { id: "C", text: "Pattabhi Sitaramayya" },
          { id: "D", text: "Jawaharlal Nehru" },
        ],
        correct: "D",
        explanation:
          "Jawaharlal Nehru moved the resolution for adopting the National Flag on July 22, 1947 in the Constituent Assembly. Pingali Venkayya designed the earlier Indian National Congress flag. Answer: D.",
        topic: "Constituent Assembly",
        difficulty: "Easy",
        pyqYear: null,
      },
      {
        id: "t01_q23",
        qNo: 23,
        text: "Consider the following personalities:\n\nI. K.M. Munshi\nII. B. N. Rau\nIII. Alladi Krishnaswami Ayyar\nIV. S. N. Mukherjee\nV. Gopalaswami Ayyangar",
        suffix:
          "How many of the above were members of the Drafting Committee of the Indian Constitution?",
        options: [
          { id: "A", text: "Only two" },
          { id: "B", text: "Only three" },
          { id: "C", text: "Only four" },
          { id: "D", text: "All the five" },
        ],
        correct: "B",
        explanation:
          "The Drafting Committee (7 members) chaired by Dr. Ambedkar included: K.M. Munshi (I ✓), Alladi Krishnaswami Ayyar (III ✓), Gopalaswami Ayyangar (V ✓), N. Madhava Rau, T.T. Krishnamachari, D.P. Khaitan, and Mohammad Saadulla. B.N. Rau (II) was the Constitutional Adviser (not a member of Drafting Committee). S.N. Mukherjee (IV) was the chief draftsman. Answer: B (only three from the list: I, III, V).",
        topic: "Drafting Committee",
        difficulty: "Hard",
        pyqYear: null,
      },
      {
        id: "t01_q24",
        qNo: 24,
        text: "With reference to the Government of India Act, 1919, consider the following statements:\n\nStatement I: At the provincial level, the act introduced the concept of responsible government, though only in a limited sense.\nStatement II: The Act categorized provincial subjects into 'transferred' and 'reserved', where transferred subjects were administered by Indian ministers who were responsible to the provincial legislature.",
        suffix:
          "Which one of the following is correct in respect of the above statements?",
        options: [
          {
            id: "A",
            text: "Both Statement I and Statement II are correct and Statement II explains Statement I",
          },
          {
            id: "B",
            text: "Both Statement I and Statement II are correct but Statement II does not explain Statement I",
          },
          {
            id: "C",
            text: "Statement I is correct but Statement II is not correct",
          },
          {
            id: "D",
            text: "Statement I is not correct but Statement II is correct",
          },
        ],
        correct: "A",
        explanation:
          "Both statements are correct. The GoI Act 1919 introduced Dyarchy at the provincial level — subjects were divided into transferred (administered by Indian ministers responsible to legislature) and reserved (administered by Governor). This system of limited responsible government (Dyarchy) explains Statement I. Statement II explains Statement I perfectly. Answer: A.",
        topic: "Constitutional History",
        difficulty: "Medium",
        pyqYear: null,
      },
      {
        id: "t01_q25",
        qNo: 25,
        text: "On 26th November 1949, which of the following provisions of the Constitution of India came into effect?\n\n1. Citizenship\n2. Elections\n3. Provisional Parliament\n4. Fundamental Rights",
        suffix: "Select the correct answer using the codes given below:",
        options: [
          { id: "A", text: "2, 3 and 4" },
          { id: "B", text: "1, 2 and 3" },
          { id: "C", text: "1 and 3 only" },
          { id: "D", text: "1 and 2 only" },
        ],
        correct: "B",
        explanation:
          "On 26 November 1949 (when the Constitution was adopted), certain provisions came into immediate effect: Citizenship (Art 5-11), Elections (Art 324-328), Provisional Parliament (Art 379-391), and the Emergency provisions. Fundamental Rights, DPSPs, and most other parts came into force on 26 January 1950. Answer: B (1, 2 and 3).",
        topic: "Commencement of Constitution",
        difficulty: "Medium",
        pyqYear: 2014,
      },
      {
        id: "t01_q26",
        qNo: 26,
        text: "The principles of liberty, equality and fraternity form a union of trinity and divorcing one from the other would defeat the very purpose of democracy. The above statement was made in the speech of which of the below personality?",
        suffix: "",
        options: [
          { id: "A", text: "Dr. Rajendra Prasad" },
          { id: "B", text: "Jawaharlal Nehru" },
          { id: "C", text: "Mahatma Gandhi" },
          { id: "D", text: "Dr. B.R. Ambedkar" },
        ],
        correct: "D",
        explanation:
          "Dr. B.R. Ambedkar in his speech to the Constituent Assembly on November 25, 1949 (the day before adoption) spoke about Liberty, Equality and Fraternity as a 'union of trinity' from the French Revolution — emphasizing that they are inseparable and together form the foundation of democracy. Answer: D.",
        topic: "Constituent Assembly",
        difficulty: "Medium",
        pyqYear: null,
      },
      {
        id: "t01_q27",
        qNo: 27,
        text: "Consider the following statements:\n\nStatement I: India transitioned from being a Dominion to a Republic on November 26, 1949.\nStatement II: The Constitution of India was adopted on November 26, 1949.",
        suffix:
          "Which one of the following is correct in respect of the above statements?",
        options: [
          {
            id: "A",
            text: "Both Statement I and Statement II are correct and Statement II explains Statement I",
          },
          {
            id: "B",
            text: "Both Statement I and Statement II are correct but Statement II does not explain Statement I",
          },
          {
            id: "C",
            text: "Statement I is correct but Statement II is not correct",
          },
          {
            id: "D",
            text: "Statement I is not correct but Statement II is correct",
          },
        ],
        correct: "D",
        explanation:
          "Statement I is incorrect — India became a Republic on January 26, 1950 (not November 26, 1949). November 26, 1949 was when the Constitution was adopted but not fully enforced. Statement II is correct — the Constitution was adopted by the Constituent Assembly on November 26, 1949. Answer: D.",
        topic: "Commencement of Constitution",
        difficulty: "Easy",
        pyqYear: null,
      },
      {
        id: "t01_q28",
        qNo: 28,
        text: "Consider the following:\n\nI. Socialist\nII. Secular\nIII. Fraternity\nIV. Equality of opportunity\nV. Dignity of the individual",
        suffix:
          "How many of the above terms were added to the Preamble through the 42nd Constitutional Amendment Act, 1976?",
        options: [
          { id: "A", text: "Only two" },
          { id: "B", text: "Only three" },
          { id: "C", text: "Only four" },
          { id: "D", text: "All the five" },
        ],
        correct: "A",
        explanation:
          "The 42nd Constitutional Amendment Act (1976) added only two words to the Preamble: 'Socialist' and 'Secular'. Fraternity, Equality of opportunity, and Dignity of the individual were already in the original Preamble. Answer: A (Only two — Socialist and Secular).",
        topic: "Preamble",
        difficulty: "Easy",
        pyqYear: 2015,
      },
      {
        id: "t01_q29",
        qNo: 29,
        text: "With reference to a republic state, consider the following statements:\n\nI. In a republic state, the head of the state is always elected for a prescribed period.\nII. A country must be a 'republic' to be recognised as a democratic nation.\nIII. The idea of a republic adopted in India was borrowed from the Constitution of the United States of America.",
        suffix: "Which of the statements given above is/are correct?",
        options: [
          { id: "A", text: "I only" },
          { id: "B", text: "I and II" },
          { id: "C", text: "II and III" },
          { id: "D", text: "I and III" },
        ],
        correct: "A",
        explanation:
          "Statement I is correct — in a republic, the head of state holds office for a fixed, prescribed term (India's President: 5 years). Statement II is incorrect — the UK is a constitutional monarchy (not a republic) yet is a democracy. Statement III is debatable and broadly incorrect — the concept of republic has ancient roots; France is also a republic. Answer: A.",
        topic: "Republican Character",
        difficulty: "Medium",
        pyqYear: null,
      },
      {
        id: "t01_q30",
        qNo: 30,
        text: "Consider the following statements:\n\nStatement I: In the Indian Constitution, the ethos of positive liberty is embedded.\nStatement II: In India, the State can impose reasonable restrictions on the liberty of citizens.\nStatement III: In India, the State facilitates the realization of certain rights and opportunities.",
        suffix:
          "Which one of the following is correct in respect of the statements given above?",
        options: [
          {
            id: "A",
            text: "Both statement II and statement III are correct and both of them explain statement I",
          },
          {
            id: "B",
            text: "Both statement II and statement III are correct, but only one of them explains statement I",
          },
          {
            id: "C",
            text: "Only one of the statements II and III is correct, and that explains statement I",
          },
          {
            id: "D",
            text: "Neither Statement II nor statement III is correct",
          },
        ],
        correct: "A",
        explanation:
          "Positive liberty means freedom to achieve one's potential with state support. Statement II (State can impose reasonable restrictions) and Statement III (State facilitates rights/opportunities through DPSPs) both explain positive liberty — the State is not just passive but actively enables liberty. Both II and III are correct and explain I. Answer: A.",
        topic: "Liberty & Political Theory",
        difficulty: "Hard",
        pyqYear: null,
      },
      {
        id: "t01_q31",
        qNo: 31,
        text: "One of the implications of equality in society is the absence of:",
        suffix: "",
        options: [
          { id: "A", text: "Privileges" },
          { id: "B", text: "Restraints" },
          { id: "C", text: "Competition" },
          { id: "D", text: "Ideology" },
        ],
        correct: "A",
        explanation:
          "Equality in society implies the absence of special privileges — no person or group should enjoy unearned advantages by birth, status, or other arbitrary factors. Equality means equal treatment under law and removal of hereditary privileges. Answer: A.",
        topic: "Equality",
        difficulty: "Easy",
        pyqYear: null,
      },
      {
        id: "t01_q32",
        qNo: 32,
        text: "With reference to Non-Resident Indians (NRIs) and Overseas Citizens of India (OCI), consider the following statements about both NRIs and OCI cardholders:\n\nI. cannot acquire agricultural land in India by way of purchase.\nII. are required to register with the local police authorities, if the period of stay exceeds 180 days in India.",
        suffix: "Which of the above given statements is/are correct?",
        options: [
          { id: "A", text: "I only" },
          { id: "B", text: "II only" },
          { id: "C", text: "Both I and II" },
          { id: "D", text: "Neither I nor II" },
        ],
        correct: "A",
        explanation:
          "Statement I is correct — Both NRIs and OCI cardholders are prohibited from purchasing agricultural land, plantation property, or farmhouses in India under FEMA regulations. Statement II is incorrect — NRIs are Indian citizens and do not need police registration. OCI cardholders were exempted from police registration requirements under the OCI scheme. Answer: A.",
        topic: "Citizenship — NRI & OCI",
        difficulty: "Hard",
        pyqYear: null,
      },
      {
        id: "t01_q33",
        qNo: 33,
        text: "Consider the following pairs:\n\nParts of the Indian Constitution — Subject Matter\nI. Part VIII — The Union Territories\nII. Part X — The Scheduled and Tribal Areas\nIII. Part XI — Relations between the Union and the States\nIV. Part XII — Elections",
        suffix: "How many of the pairs given above are correctly matched?",
        options: [
          { id: "A", text: "Only one" },
          { id: "B", text: "Only two" },
          { id: "C", text: "Only three" },
          { id: "D", text: "All the four" },
        ],
        correct: "C",
        explanation:
          "Part VIII (Union Territories) ✓; Part X (Scheduled and Tribal Areas) ✓; Part XI (Relations between Union and States) ✓; Part XII is NOT Elections — Part XII deals with Finance, Property, Contracts and Suits. Part XV deals with Elections. Three pairs are correct. Answer: C.",
        topic: "Parts of Constitution",
        difficulty: "Medium",
        pyqYear: null,
      },
      {
        id: "t01_q34",
        qNo: 34,
        text: "In general, which one of the following is a primary function of a Constitution?",
        suffix: "",
        options: [
          {
            id: "A",
            text: "It ensures complete separation among different organs of the state.",
          },
          {
            id: "B",
            text: "It provides a set of ideals that reflects the moral and political identity of a country's citizens.",
          },
          {
            id: "C",
            text: "It ensures equal distribution of wealth and resources among the citizens.",
          },
          {
            id: "D",
            text: "It ensures that outcomes of the Parliamentary and assembly elections are always fair and free from disputes.",
          },
        ],
        correct: "B",
        explanation:
          "The primary function of a Constitution is to express the fundamental values and political identity of a people — it embodies their ideals, aspirations, and principles of governance. While it also separates powers, distributes resources, etc., the core function is providing a foundational framework of values. Answer: B.",
        topic: "Constitutional Theory",
        difficulty: "Easy",
        pyqYear: null,
      },
      {
        id: "t01_q35",
        qNo: 35,
        text: "The citizenship means\n\n1. full civil and political rights of the citizens.\n2. the right of suffrage for election to the House of the People (of the Union) and the Legislative Assembly of every state.\n3. the right to become a Member of Parliament and Member of Legislative Assemblies.",
        suffix: "Select the correct answer using the codes given below:",
        options: [
          { id: "A", text: "1 and 2 only" },
          { id: "B", text: "1 and 3 only" },
          { id: "C", text: "2 and 3 only" },
          { id: "D", text: "All of these" },
        ],
        correct: "D",
        explanation:
          "Citizenship confers full civil and political rights including: the right to vote (suffrage) in elections to Parliament and State legislatures, and the right to contest elections and become MPs and MLAs. All three elements are part of citizenship. Answer: D.",
        topic: "Citizenship",
        difficulty: "Easy",
        pyqYear: null,
      },
      {
        id: "t01_q36",
        qNo: 36,
        text: "Consider the following statements:\n\nStatement I: The Supreme Court of India is the custodian of the Constitution of India.\nStatement II: The Constitution of India establishes a single, integrated judicial system with the Supreme Court placed at its apex.",
        suffix:
          "Which one of the following is correct in respect of the above statements?",
        options: [
          {
            id: "A",
            text: "Both Statement I and Statement II are correct and Statement II explains Statement I",
          },
          {
            id: "B",
            text: "Both Statement I and Statement II are correct but Statement II does not explain Statement I",
          },
          {
            id: "C",
            text: "Statement I is correct but Statement II is not correct",
          },
          {
            id: "D",
            text: "Statement I is not correct but Statement II is correct",
          },
        ],
        correct: "B",
        explanation:
          "Both are correct. The Supreme Court is the guardian/custodian of the Constitution through judicial review. India has a single integrated judiciary with SC at the apex. However, Statement II does not explain I — being the apex court in an integrated system is separate from being the Constitution's custodian (the latter arises from the power of judicial review). Answer: B.",
        topic: "Judiciary",
        difficulty: "Medium",
        pyqYear: null,
      },
      {
        id: "t01_q37",
        qNo: 37,
        text: "Which of the following features essentially ensure constitutionalism in India?\n\nI. Rule of law\nII. Fundamental Rights to citizens\nIII. Separation of powers between different organs of Government\nIV. Judicial Review",
        suffix: "Select the correct answer using the code given below:",
        options: [
          { id: "A", text: "I and II only" },
          { id: "B", text: "II and III only" },
          { id: "C", text: "I, II and III only" },
          { id: "D", text: "I, II, III and IV" },
        ],
        correct: "D",
        explanation:
          "Constitutionalism means limiting government power through a constitution. All four — Rule of Law, Fundamental Rights, Separation of Powers, and Judicial Review — are essential pillars of constitutionalism in India. They collectively ensure limited, accountable government. Answer: D.",
        topic: "Constitutionalism",
        difficulty: "Medium",
        pyqYear: null,
      },
      {
        id: "t01_q38",
        qNo: 38,
        text: "The Constituent Assembly of India performed which of the following functions?\n\nI. Ratified India's membership to the Commonwealth\nII. Elected Dr. Rajendra Prasad as India's first President\nIII. Adopted the National Flag of India",
        suffix: "Select the correct answer using the code given below:",
        options: [
          { id: "A", text: "II and III only" },
          { id: "B", text: "I and III only" },
          { id: "C", text: "I and II only" },
          { id: "D", text: "I, II and III" },
        ],
        correct: "D",
        explanation:
          "The Constituent Assembly also served as the Provisional Parliament. It ratified Commonwealth membership (1949), adopted the National Flag (July 1947), and elected Dr. Rajendra Prasad as the first President of India (January 1950). All three are correct. Answer: D.",
        topic: "Constituent Assembly",
        difficulty: "Medium",
        pyqYear: null,
      },
      {
        id: "t01_q39",
        qNo: 39,
        text: "Consider the following statements:\n\nI. The Preamble to the Constitution of India can be amended by Parliament through a majority of the total membership of each House and two-thirds of the members present and voting.\nII. The Preamble is neither a source of power nor a prohibition upon the legislative power of the Parliament.",
        suffix: "Which of the statements given above is/are correct?",
        options: [
          { id: "A", text: "I only" },
          { id: "B", text: "II only" },
          { id: "C", text: "Both I and II" },
          { id: "D", text: "Neither I nor II" },
        ],
        correct: "C",
        explanation:
          "Statement I is correct — in Kesavananda Bharati (1973), the SC held the Preamble can be amended as it is part of the Constitution, subject to the basic structure doctrine. The amendment procedure requires 2/3 majority of members present and voting + majority of total membership. Statement II is correct — the Preamble is not a legislative source of power but an aid to interpretation (Berubari Case 1960). Answer: C.",
        topic: "Preamble",
        difficulty: "Medium",
        pyqYear: null,
      },
      {
        id: "t01_q40",
        qNo: 40,
        text: "The concept of 'A Union of States in the Indian Constitution' has been derived from-",
        suffix: "",
        options: [
          { id: "A", text: "The American Declaration of Independence" },
          { id: "B", text: "The Australian Constitution" },
          { id: "C", text: "The British North American Act" },
          { id: "D", text: "The Swiss Constitution" },
        ],
        correct: "C",
        explanation:
          "The term 'Union of States' (Article 1 — India, that is Bharat, shall be a Union of States) was inspired by the British North America Act (now the Constitution Act, 1867) of Canada. Canada's constitution uses 'union' to describe its federation, emphasizing the indestructibility of the federation. Answer: C.",
        topic: "Sources of Constitution",
        difficulty: "Hard",
        pyqYear: null,
      },
      {
        id: "t01_q41",
        qNo: 41,
        text: "Which one of the following factors constitutes the best safeguard of liberty in a liberal democracy?",
        suffix: "",
        options: [
          { id: "A", text: "A committed judiciary" },
          { id: "B", text: "Centralization of powers" },
          { id: "C", text: "Elected government" },
          { id: "D", text: "Separation of powers" },
        ],
        correct: "D",
        explanation:
          "Separation of powers (Montesquieu) is the best safeguard of liberty — when legislative, executive, and judicial powers are separated, no single authority can become tyrannical. While an independent judiciary is important, structural separation of powers is more foundational. Answer: D.",
        topic: "Liberty & Separation of Powers",
        difficulty: "Easy",
        pyqYear: 2021,
      },
      {
        id: "t01_q42",
        qNo: 42,
        text: "Arrange the following committees/commissions related to the reorganization of States in India in chronological order:\n\nI. S.K. Dhar Commission\nII. Fazl Ali Commission\nIII. JVP Committee",
        suffix: "Select the correct answer using the codes given below:",
        options: [
          { id: "A", text: "I-III-II" },
          { id: "B", text: "II-I-III" },
          { id: "C", text: "II-III-I" },
          { id: "D", text: "I-II-III" },
        ],
        correct: "A",
        explanation:
          "S.K. Dhar Commission (1948) — first commission set up to examine linguistic states, recommended against linguistic basis. JVP Committee (Jawaharlal, Vallabhbhai, Pattabhi — 1949) — reexamined the issue. States Reorganisation Commission/Fazl Ali Commission (1953-55) — recommended reorganization on linguistic basis. Chronological order: I → III → II. Answer: A.",
        topic: "States Reorganisation",
        difficulty: "Medium",
        pyqYear: null,
      },
      {
        id: "t01_q43",
        qNo: 43,
        text: "To create a new state from an existing state in India, which one of the following Schedules of the Constitution needs to be amended?",
        suffix: "",
        options: [
          { id: "A", text: "First Schedule" },
          { id: "B", text: "Third Schedule" },
          { id: "C", text: "Seventh Schedule" },
          { id: "D", text: "Eighth Schedule" },
        ],
        correct: "A",
        explanation:
          "The First Schedule of the Constitution contains the list of States and Union Territories with their territories. When a new state is created, the First Schedule must be amended to add the new state and modify the territory of the parent state. Answer: A.",
        topic: "Constitutional Schedules",
        difficulty: "Easy",
        pyqYear: null,
      },
      {
        id: "t01_q44",
        qNo: 44,
        text: "Under the Citizenship Act, 1955, a citizen of India who has acquired his/her citizenship through naturalization can lose his/her citizenship by way of deprivation if:\n\nI. s/he has obtained citizenship by fraud or concealment of material facts.\nII. s/he has shown disloyalty or disaffection towards the Constitution of India.\nIII. during a war, if s/he is found to have traded or communicated with the enemy in a manner that assists the enemy.",
        suffix: "Which of the statements given above are correct?",
        options: [
          { id: "A", text: "I, II and III" },
          { id: "B", text: "I and II only" },
          { id: "C", text: "I and III only" },
          { id: "D", text: "II and III only" },
        ],
        correct: "A",
        explanation:
          "Under Section 10 of the Citizenship Act 1955, the Government can deprive a naturalized citizen of citizenship if: they obtained it by fraud (I ✓), showed disloyalty to the Constitution (II ✓), during wartime traded/communicated with the enemy (III ✓). All three are valid grounds for deprivation. Answer: A.",
        topic: "Citizenship",
        difficulty: "Medium",
        pyqYear: null,
      },
      {
        id: "t01_q45",
        qNo: 45,
        text: "What was the exact constitutional status of India on 26th January, 1950?",
        suffix: "",
        options: [
          { id: "A", text: "A Democratic Republic" },
          { id: "B", text: "A Sovereign Democratic Republic" },
          { id: "C", text: "A sovereign Secular Democratic" },
          {
            id: "D",
            text: "A sovereign Socialist secular Democratic Republic",
          },
        ],
        correct: "B",
        explanation:
          "On 26th January 1950, the original Preamble described India as a 'Sovereign Democratic Republic'. The words 'Socialist' and 'Secular' were added only by the 42nd Constitutional Amendment in 1976. Answer: B.",
        topic: "Preamble",
        difficulty: "Easy",
        pyqYear: 2016,
      },
      {
        id: "t01_q46",
        qNo: 46,
        text: "Consider the following:\n\nI. Speaker of the House of People\nII. Comptroller and Auditor General of India\nIII. Judge of the High Court\nIV. President",
        suffix:
          "How many of the above constitutional posts are mentioned in both the second and third schedule of the Indian Constitution?",
        options: [
          { id: "A", text: "Only one" },
          { id: "B", text: "Only two" },
          { id: "C", text: "Only three" },
          { id: "D", text: "All the four" },
        ],
        correct: "B",
        explanation:
          "The Second Schedule contains provisions relating to emoluments, allowances, and rights of: President, Governors, Speaker/Deputy Speaker (LS/RS), Judges of SC and HC, and CAG. The Third Schedule contains Forms of Oaths/Affirmations for: Members of Parliament/Legislature, Ministers, President, Vice President, Judges (SC/HC), CAG. Commonly appearing in both: Judge of High Court (III ✓) and CAG (II ✓). Answer: B (Only two).",
        topic: "Constitutional Schedules",
        difficulty: "Hard",
        pyqYear: null,
      },
      {
        id: "t01_q47",
        qNo: 47,
        text: "With reference to present procedure of granting citizenship in India, consider the following statements:\n\nStatement I: In India, the citizenship of a child is determined by the citizenship of his/her parents.\nStatement II: India currently follows the jus soli principle for determining a person's citizenship.",
        suffix:
          "Which one of the following is correct in respect of the above statements?",
        options: [
          {
            id: "A",
            text: "Both Statement I and Statement II are correct and Statement II explains Statement I.",
          },
          {
            id: "B",
            text: "Both Statement I and Statement II are correct, but Statement II does not explain Statement I.",
          },
          {
            id: "C",
            text: "Statement I is correct, but Statement II is not correct.",
          },
          {
            id: "D",
            text: "Statement I is not correct, but Statement II is correct.",
          },
        ],
        correct: "C",
        explanation:
          "Statement I is correct — India follows jus sanguinis (citizenship by descent/blood), where a child's citizenship is determined by parents' citizenship. Statement II is incorrect — India does NOT follow jus soli (citizenship by place of birth) for most purposes; if a child is born in India to foreign parents, they may not automatically get citizenship. Answer: C.",
        topic: "Citizenship",
        difficulty: "Medium",
        pyqYear: null,
      },
      {
        id: "t01_q48",
        qNo: 48,
        text: "With reference to the Committees formed by the Constituent Assembly of India, consider the following pairs:\n\nCommittees — Headed by\nI. States Committee — Vallabhbhai Patel\nII. Union Powers Committee — Jawaharlal Nehru\nIII. Committee on Rules of Procedure — Rajendra Prasad",
        suffix: "How many of the pairs given above are correctly matched?",
        options: [
          { id: "A", text: "Only one" },
          { id: "B", text: "Only two" },
          { id: "C", text: "All the three" },
          { id: "D", text: "None" },
        ],
        correct: "C",
        explanation:
          "All three are correct. States Committee was chaired by Vallabhbhai Patel. Union Powers Committee was chaired by Jawaharlal Nehru. Committee on Rules of Procedure was chaired by Dr. Rajendra Prasad (who was the President of the Assembly). Answer: C.",
        topic: "Constituent Assembly Committees",
        difficulty: "Hard",
        pyqYear: null,
      },
      {
        id: "t01_q49",
        qNo: 49,
        text: "During British colonial rule in India, under which Act were Indians for the first time included in the Viceroy's Executive Council?",
        suffix: "",
        options: [
          { id: "A", text: "Indian Councils Act, 1861" },
          { id: "B", text: "Indian Councils Act, 1892" },
          { id: "C", text: "Indian Councils Act, 1909" },
          { id: "D", text: "Government of India Act, 1919" },
        ],
        correct: "C",
        explanation:
          "The Indian Councils Act 1909 (Morley-Minto Reforms) provided for the inclusion of Indians in the Viceroy's Executive Council for the first time — Satyendra Prasad Sinha was appointed as the first Indian member of the Viceroy's Executive Council. Answer: C.",
        topic: "Constitutional History",
        difficulty: "Medium",
        pyqYear: null,
      },
      {
        id: "t01_q50",
        qNo: 50,
        text: "As per the Preamble of the Constitution of India, Fraternity does not aim to assure which of the following:",
        suffix: "",
        options: [
          { id: "A", text: "Dignity of the individual" },
          { id: "B", text: "Unity of the nation" },
          { id: "C", text: "Integrity of the nation" },
          {
            id: "D",
            text: "Equality of status and opportunity for the citizens.",
          },
        ],
        correct: "D",
        explanation:
          "As per the Preamble, Fraternity aims to assure: (i) Dignity of the individual, and (ii) Unity and Integrity of the Nation. Equality of status and opportunity is assured by the word 'Equality' in the Preamble, not Fraternity. Answer: D.",
        topic: "Preamble",
        difficulty: "Easy",
        pyqYear: null,
      },
    ],
  }
];

export default TEST_T1;
